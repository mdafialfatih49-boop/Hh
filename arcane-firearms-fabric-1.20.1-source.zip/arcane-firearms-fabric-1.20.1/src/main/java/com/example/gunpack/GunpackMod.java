package com.example.gunpack;

import com.example.gunpack.item.ArcaneBlasterItem;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.itemgroup.v1.ItemGroupEvents;
import net.minecraft.item.Item;
import net.minecraft.item.ItemGroups;
import net.minecraft.registry.Registries;
import net.minecraft.registry.Registry;
import net.minecraft.util.Identifier;

public class GunpackMod implements ModInitializer {
    public static final String MOD_ID = "gunpack";

    private static Item register(String path, double damage, float speed, int cooldown) {
        Item item = new ArcaneBlasterItem(
                new Item.Settings().maxDamage(320), damage, speed, cooldown
        );
        return Registry.register(Registries.ITEM, new Identifier(MOD_ID, path), item);
    }

    public static final Item EMBER_BLASTER = register("ember_blaster", 5.0, 3.2F, 12);
    public static final Item FROST_PULSE = register("frost_pulse", 4.0, 3.0F, 14);
    public static final Item VERDANT_REPEATER = register("verdant_repeater", 3.0, 3.5F, 8);
    public static final Item ARCANE_CARBINE = register("arcane_carbine", 5.5, 3.3F, 16);
    public static final Item STORMCASTER = register("stormcaster", 4.5, 3.8F, 18);
    public static final Item VOID_PIERCER = register("void_piercer", 7.0, 4.0F, 25);
    public static final Item PRISM_LAUNCHER = register("prism_launcher", 6.0, 2.8F, 22);
    public static final Item SONIC_BLASTER = register("sonic_blaster", 3.5, 3.6F, 10);
    public static final Item STARFALL_RIFLE = register("starfall_rifle", 6.5, 3.5F, 24);
    public static final Item CRYSTAL_CANNON = register("crystal_cannon", 8.0, 2.7F, 30);

    @Override
    public void onInitialize() {
        ItemGroupEvents.modifyEntriesEvent(ItemGroups.COMBAT).register(entries -> {
            entries.add(EMBER_BLASTER);
            entries.add(FROST_PULSE);
            entries.add(VERDANT_REPEATER);
            entries.add(ARCANE_CARBINE);
            entries.add(STORMCASTER);
            entries.add(VOID_PIERCER);
            entries.add(PRISM_LAUNCHER);
            entries.add(SONIC_BLASTER);
            entries.add(STARFALL_RIFLE);
            entries.add(CRYSTAL_CANNON);
        });
    }
}
