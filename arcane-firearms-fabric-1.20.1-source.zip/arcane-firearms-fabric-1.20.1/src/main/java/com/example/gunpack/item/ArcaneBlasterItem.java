package com.example.gunpack.item;

import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.entity.projectile.ArrowEntity;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.sound.SoundCategory;
import net.minecraft.sound.SoundEvents;
import net.minecraft.util.Hand;
import net.minecraft.util.TypedActionResult;
import net.minecraft.world.World;

/**
 * A purely fictional Minecraft energy blaster.
 * It reuses the vanilla arrow entity as an in-game projectile; it does not
 * model real-world firearm mechanics.
 */
public class ArcaneBlasterItem extends Item {
    private final double projectileDamage;
    private final float projectileSpeed;
    private final int cooldownTicks;

    public ArcaneBlasterItem(Settings settings, double projectileDamage,
                             float projectileSpeed, int cooldownTicks) {
        super(settings);
        this.projectileDamage = projectileDamage;
        this.projectileSpeed = projectileSpeed;
        this.cooldownTicks = cooldownTicks;
    }

    @Override
    public TypedActionResult<ItemStack> use(World world, PlayerEntity user, Hand hand) {
        ItemStack stack = user.getStackInHand(hand);

        if (!world.isClient) {
            ArrowEntity projectile = new ArrowEntity(world, user);
            projectile.setDamage(projectileDamage);
            projectile.setVelocity(
                    user,
                    user.getPitch(),
                    user.getYaw(),
                    0.0F,
                    projectileSpeed,
                    0.15F
            );
            world.spawnEntity(projectile);
            world.playSound(
                    null,
                    user.getX(), user.getY(), user.getZ(),
                    SoundEvents.ENTITY_ARROW_SHOOT,
                    SoundCategory.PLAYERS,
                    0.8F,
                    1.15F
            );
            stack.damage(1, user, player -> player.sendToolBreakStatus(hand));
        }

        user.getItemCooldownManager().set(this, cooldownTicks);
        return TypedActionResult.success(stack, world.isClient);
    }
}
