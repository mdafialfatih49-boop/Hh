# Arcane Firearms Pack — Fabric 1.20.1

Mod ini menambahkan **10 senjata energi fiksi** bertema sci-fi/fantasi ke Minecraft Java 1.20.1. Senjata menggunakan proyektil panah vanilla sebagai mekanik permainan, memiliki damage, kecepatan, cooldown, dan durability yang berbeda. Semua item tersedia di tab **Combat** dan mempunyai resep crafting.

## Daftar item

| Item | Damage | Cooldown | Karakter gameplay |
|---|---:|---:|---|
| Ember Blaster | 5.0 | 12 tick | Blaster serbaguna |
| Frost Pulse | 4.0 | 14 tick | Tembakan energi stabil |
| Verdant Repeater | 3.0 | 8 tick | Cepat, damage ringan |
| Arcane Carbine | 5.5 | 16 tick | Seimbang |
| Stormcaster | 4.5 | 18 tick | Proyektil cepat |
| Void Piercer | 7.0 | 25 tick | Damage tinggi |
| Prism Launcher | 6.0 | 22 tick | Damage menengah-tinggi |
| Sonic Blaster | 3.5 | 10 tick | Cepat untuk gameplay |
| Starfall Rifle | 6.5 | 24 tick | Damage tinggi |
| Crystal Cannon | 8.0 | 30 tick | Damage tertinggi, cooldown lama |

Setiap tembakan mengurangi 1 durability. Item dapat diperbaiki melalui mekanisme anvil vanilla.

## Dependensi

- Minecraft Java Edition **1.20.1**
- Fabric Loader **0.15.11 atau lebih baru**
- Fabric API **0.92.2+1.20.1**
- Java **17**

## Cara build menjadi JAR

### Cara otomatis melalui GitHub (bisa dari Android)

1. Ekstrak ZIP proyek ini.
2. Buat repository baru di GitHub.
3. Upload **isi folder proyek** ke repository (pastikan folder `.github/workflows` ikut ter-upload).
4. Buka tab **Actions** pada repository.
5. Pilih workflow **Build Fabric Mod**, lalu tekan **Run workflow**. Workflow juga berjalan otomatis saat ada push.
6. Setelah selesai, buka hasil run dan unduh artifact bernama `arcane-firearms-fabric-1.20.1`.
7. Ekstrak artifact tersebut. File mod berakhiran `.jar` ada di dalamnya.

### Cara build di komputer

Pastikan Java 17 dan Gradle 8.7 tersedia, lalu jalankan dari folder proyek:

```bash
gradle build
```

JAR hasil build berada di `build/libs/`.

## Cara memasang

1. Pasang Fabric Loader untuk Minecraft 1.20.1.
2. Unduh Fabric API 1.20.1.
3. Salin file `arcane-firearms-1.0.0.jar` hasil build dan file Fabric API ke folder `mods` pada direktori Minecraft yang digunakan.
4. Jalankan profil Fabric 1.20.1.
5. Cari item di tab **Combat** pada Creative Mode, atau buat melalui resep crafting.

Di Android, gunakan folder `.minecraft/mods` milik launcher Java yang kamu pakai (misalnya PojavLauncher). Pastikan launcher menjalankan instance Fabric 1.20.1 yang sama.

## Catatan teknis

Source code menggunakan Java 17, Yarn mappings `1.20.1+build.10`, Fabric Loom 1.6.12, dan Fabric API. Proyek ini disiapkan sebagai source project; file JAR perlu dibangun melalui workflow GitHub atau Gradle.
